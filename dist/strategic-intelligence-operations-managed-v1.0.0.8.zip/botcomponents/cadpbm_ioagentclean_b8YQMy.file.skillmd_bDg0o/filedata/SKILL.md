---
name: process-work-item-result
description: Interpret worker results for IO Work Items and decide whether remediation or synthesis is needed. Never publishes.
---
<!-- bic:source=blank -->
# Process Work Item Result

Use to validate evidence and findings written by the inline worker for one or more IO Work Items, and to decide the right next status. This skill never publishes anything.

## When to use this skill

- The user asks for the status of a run/work items, or asks the agent to check whether processing has finished or needs attention.
- A work item has come back Needs Review or Needs Remediation and the user wants the agent's read on what to do.

## Background: work item lifecycle

Work items move through Search Status values: Draft → Queued → In Progress → one of Completed, No Material Activity, Needs Review, Needs Remediation, Failed, Skipped (see `choices_and_status_codes.md` knowledge for exact values). Processing itself is performed by an automated flow and inline worker (see `_pending_tools/automated-workflow-and-inline-worker.md`); this skill is how the agent reasons about the *results* of that processing, not how it performs the research itself.

## Procedure

1. Read the IO Work Item(s) for the run in question, including Search Status, Retries and Worker Notes.
2. For each work item, read its linked IO Evidence Source and IO Finding rows.
3. Validate:
   - Findings reference evidence IDs where evidence exists.
   - Findings are not vague or unsupported — flag any finding lacking evidence as Needs Review rather than accepting it.
   - No Material Activity is a legitimate terminal state, not a failure, when a work item genuinely found nothing.
4. Decide/report the appropriate work item Search Status. Needs Review is reserved for usable ambiguity; setup and system problems never reach a human:
   - **Completed** - evidence and findings are present and well-formed, OR the item has usable findings and every one is Ready For Synthesis (even if the worker flagged Needs Review).
   - **No Material Activity** - the worker found nothing material for this entity/source in the period; this is expected, not an error.
   - **Needs Remediation** - attempts 1 and 2 only: incomplete but retryable research (transient failure, incomplete search, source gap).
   - **Needs Review** - only after the final allowed attempt, and only when at least one usable finding needs a human decision (Low confidence, high-impact Risk below High confidence, single vendor/self-reported claim, or Candidate Entity).
   - **Failed** - a setup/system defect (worker note tagged [SETUP]), or the final attempt ended with no usable findings. Always keep the real error in Worker Notes; never replace it with a generic message.
5. Once all work items for a run are in a terminal state (Completed, No Material Activity, Needs Review, Failed or Skipped), tell the user the run is ready for synthesis and hand off to the synthesise-output skill (do not synthesise here).
6. If any work item is Failed, flag that the run may need Review Required handling rather than full automatic synthesis, unless the user confirms partial synthesis is acceptable.

## Review load policy

- Findings: Ready For Synthesis for High confidence, and for Medium confidence with credible independent support. Needs Review only for Low confidence, high-impact Risk below High confidence, single vendor/self-reported claims and Candidate Entity. Interpretation, Forward-looking and Not independently validated are labels, not review triggers.
- When reporting a run, give the human effort up front, for example "9 must-review, 39 Medium auto-accepted (spot-check 10-20%), 72 High auto-accepted", and list must-review findings first with their [REVIEW: reason].
- Summaries are 500 characters or fewer; detail lives in Evidence Sources.

## Guardrails

- Do not publish, approve, or write outputs from this skill — it only classifies and reports on work item Search Status.
- Do not mark a work item Completed if its findings lack any evidence reference and evidence was expected.
- Respect the Retries ceiling (3) before recommending Failed.

